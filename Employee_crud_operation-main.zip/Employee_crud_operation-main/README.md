# Employee_crud_operation
using django rest api
